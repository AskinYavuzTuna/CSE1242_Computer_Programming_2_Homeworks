//This class represents any Food which is sold.
public abstract class Food extends Item {

	Food(){
		super.setVat(0.08);
	}
}
