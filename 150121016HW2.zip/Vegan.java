//This interface represents Vegan feature.
public interface Vegan {
	
	public abstract void madeOf();
	
}
