//This interface represents Washable feature.
public interface Washable {
	
	public abstract void howToWash();

}
